import "./globals.css";
import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Inter } from "next/font/google";
import Parallax from "@/components/Parallax";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "Bahtera Artaniaga | Distribusi & Perdagangan",
  description:
    "Bahtera Artaniaga adalah perusahaan distribusi dan perdagangan yang profesional, efisien, dan terpercaya.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className={`${inter.variable} font-sans bg-white text-slate-900`}>
        <Parallax />
        <div className="max-w-6xl mx-auto px-6 pt-28">
          <Navbar />
          {children}
          <Footer />
        </div>
      </body>
    </html>
  );
}
