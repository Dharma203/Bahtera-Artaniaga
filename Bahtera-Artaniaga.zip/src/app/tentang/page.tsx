export const metadata = {
  title: "Tentang Kami | Bahtera Artaniaga",
  description:
    "Profil Bahtera Artaniaga sebagai perusahaan distribusi dan perdagangan yang profesional dan terpercaya.",
};

export default function Tentang() {
  return (
    <main className="py-20">
      <section className="max-w-3xl mx-auto text-center">
        <h1 className="text-3xl md:text-4xl font-semibold text-slate-800">
          Tentang Bahtera Artaniaga
        </h1>
        <p className="mt-6 text-slate-500 leading-relaxed">
          Bahtera Artaniaga adalah perusahaan yang bergerak di bidang distribusi
          dan perdagangan umum dengan komitmen menghadirkan layanan yang
          profesional, efisien, dan terpercaya bagi setiap mitra bisnis.
        </p>
      </section>

      <section className="mt-20 grid md:grid-cols-2 gap-12">
        <div className="p-8 bg-white border border-slate-200 rounded-xl shadow-sm">
          <h2 className="text-xl font-semibold text-slate-800">Visi</h2>
          <p className="mt-4 text-slate-500 text-sm leading-relaxed">
            Menjadi perusahaan distribusi dan perdagangan yang unggul, inovatif,
            dan terpercaya dalam mendukung pertumbuhan bisnis mitra kami.
          </p>
        </div>

        <div className="p-8 bg-white border border-slate-200 rounded-xl shadow-sm">
          <h2 className="text-xl font-semibold text-slate-800">Misi</h2>
          <ul className="mt-4 text-slate-500 text-sm space-y-2 list-disc list-inside">
            <li>Menyediakan layanan distribusi yang efisien</li>
            <li>Menjaga kualitas produk dan layanan</li>
            <li>Membangun kemitraan jangka panjang</li>
            <li>Mengutamakan profesionalisme dan integritas</li>
          </ul>
        </div>
      </section>
    </main>
  );
}
