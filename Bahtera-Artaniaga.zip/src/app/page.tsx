import Reveal from "@/components/Reveal";

export default function Home() {
  return (
    <main>
      <Reveal>
        <section className="relative overflow-hidden pt-44 pb-56">
          <div className="absolute inset-0 -z-10 bg-gradient-to-b from-slate-100 via-white to-white"></div>
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[900px] bg-blue-100/30 rounded-full blur-3xl -z-10"></div>
          <div className="max-w-3xl mx-auto text-center">
            <small>Bahtera Artaniaga</small>
            <h2>
              Solusi Distribusi <span className="text-blue-600">Modern</span>
            </h2>
            <p className="mt-8">
              Kami menghadirkan sistem distribusi modern yang mendukung
              pertumbuhan bisnis Anda.
            </p>
          </div>
        </section>
      </Reveal>
      <Reveal>
        <section className="section-layer pt-44 pb-52 bg-gradient-to-b from-white to-slate-50">
          <div className="absolute inset-0 bg-slate-100 -z-10"></div>

          <div className="max-w-6xl mx-auto px-6">
            <div className="parallax h-[560px] rounded-[2.5rem] overflow-hidden shadow-xl">
              <img
                src="warehouse.jpg"
                alt="Distribusi modern"
                className="brand-image w-full h-full object-cover"
              />
            </div>
          </div>
        </section>
      </Reveal>
      <Reveal>
        <section className="section-layer pt-52 pb-44 bg-slate-50">
          <div className="grid md:grid-cols-2 gap-24 items-start">
            <div>
              <h2 className="text-3xl font-semibold text-slate-900">
                Efisiensi dalam Setiap Proses
              </h2>
              <p className="mt-6 text-slate-500 leading-relaxed max-w-md">
                Kami mengelola rantai distribusi dengan sistem yang terstruktur,
                memastikan kelancaran operasional bisnis mitra kami.
              </p>
            </div>

            <div></div>
          </div>
        </section>
      </Reveal>
      <Reveal>
        <section className="section-layer pt-44 pb-52 bg-gradient-to-b from-slate-50 to-white">
          <div className="max-w-3xl">
            <h2 className="text-3xl font-semibold text-slate-900">
              Standar Profesional Tinggi
            </h2>
            <p className="mt-6 text-slate-600">
              Komitmen kami pada kualitas dan integritas menjadikan kami mitra
              terpercaya di bidang distribusi dan perdagangan.
            </p>
          </div>
        </section>
      </Reveal>
      <Reveal>
        <section className="section-layer pt-52 pb-44 bg-white text-center">
          <h2 className="text-3xl md:text-4xl font-semibold text-slate-900">
            Siap Bekerja Sama dengan Kami?
          </h2>

          <p className="mt-6 text-slate-500">
            Hubungi Bahtera Artaniaga untuk solusi distribusi dan perdagangan
            yang profesional.
          </p>

          <a
            href="/kontak"
            className="inline-block mt-12 px-10 py-4 bg-slate-950 text-white rounded-full text-sm tracking-wide transition-all duration-300 hover:scale-105"
          >
            Hubungi Kami
          </a>
        </section>
      </Reveal>
    </main>
  );
}
